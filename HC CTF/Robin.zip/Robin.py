from Crypto.Util.number import isPrime
from random import getrandbits

flag = open('flag.txt').read().strip()
while(len(flag)<100):
    flag+='A'
flag = int(flag.encode('hex'),16)

def GenKey(k):
    while True:
        r=getrandbits(k)
        while(r%2):
            r=getrandbits(k)
        vp = 36655
        vq = 6695
        c = 5
        p = vp + (c*2)*r + (c*3) * r**2
        q = vq + (c*17) * r**2 + (c*18) * r
        p /= 5
        q /= 5
        n = p * q
        if(isPrime(p) and isPrime(q)):
            return (p,q) , n

private_key,public_key = GenKey(256)

cipher = flag**2 % public_key

with open('flag.enc','w') as f:
	f.write('Cipher Text = ' + str(cipher))
with open('public_key.txt','w') as f:
	f.write('Public Key = ' + str(public_key))

with open('private_key.txt','w') as f:
	f.write('Private Key = ' + str(private_key))
